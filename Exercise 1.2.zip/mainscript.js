//let us create few variables:

var x;
let y;

//let add some values to the variables

x = 9;
y = 16;

//lets add these variables

let z = x + y;

//assume a constant which cannot be reassigned 

const PI = 3.141592653589793;

console.log("PI: " + PI);

//now lets combine multiple strings (combination of letters and other values)

var first_name = "Ajay";
var last_name = "Kareer";

let full_name = first_name + " " + last_name;

console.log("First Name: " + first_name + ", Last Name: " + last_name);
console.log("Full Name : " + full_name);

console.log("X: " + x + "\n" + "Y: " + y + "\n" + "Z: " + z);

console.log("This is" + " a " + "combined string with an integer: " + z);

//lets incriment a number by 1

let incriment_num = 99;

console.log("The Number : " + incriment_num);

incriment_num++;

console.log("The incremented number: " + incriment_num);

//lets multiply an integer number

var a;
var b;

a = 5;
b = 7;

c = a*b;

console.log("First Number : " + a + " Second Number : " + b);
console.log("Multiplication of First Number and Second Number is : " + c);